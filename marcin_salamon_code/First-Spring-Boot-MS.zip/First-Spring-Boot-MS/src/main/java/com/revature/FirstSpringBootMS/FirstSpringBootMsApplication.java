package com.revature.FirstSpringBootMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootMsApplication.class, args);
	}
}
